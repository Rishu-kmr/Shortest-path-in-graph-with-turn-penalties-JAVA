package col106.assignment6;



class Node implements Comparable<Node>{
	dualVertex dualvertex;
	double weight;
	public Node(dualVertex dualvertex, double weight) {
		this.dualvertex = dualvertex;
		this.weight = weight;
	}
	@Override
	public int compareTo(Node o) {
		// TODO Auto-generated method stub
		if(this.weight<o.weight) {
			return -1;
		}
		if(this.weight>o.weight) {
			return 1;
		}
		return 0;
	}
}