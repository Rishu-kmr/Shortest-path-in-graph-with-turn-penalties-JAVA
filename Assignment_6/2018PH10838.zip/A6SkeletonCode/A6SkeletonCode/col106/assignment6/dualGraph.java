package col106.assignment6;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Queue;

class dualGraph{
	private int dualedge;
	private int dualnode;
	private Digraph digraph;
	private int[] source;
	private int[] destination;
	private int costLeft;
	private int costRight;
	private int costForward;
	private ArrayList<Edge>[] adj;      // adj[v] = adjacency list for vertex v
    private HashMap<Integer,dualVertex> map;
    private boolean[] notvisitedEdge;
	public dualGraph(final Digraph G, final int[] s, final int[] t, final int left, final int right, final int forward) {
		this.digraph = G;
    	this.source = s;
    	this.destination = t;
    	this.costLeft = left;
    	this.costRight = right;
    	this.costForward = forward;
    	adj = new ArrayList[4*this.digraph.V()];
    	notvisitedEdge = new boolean[4*this.digraph.V()];
    	for(int i=0; i<4*this.digraph.V(); i++) {
    		adj[i] = new ArrayList<Edge>();
    		notvisitedEdge[i] = true;
    	}
    	map = new HashMap<Integer,dualVertex>();
    	int i1 = this.source[0];
    	int j1 = this.source[1];
    	int key1 = i1*this.digraph.W()+j1;
    	Queue<Vertex> queue = new ArrayDeque<>();
    	Queue<Integer> que = new ArrayDeque<>();
    	queue.add(this.digraph.nodemap(key1));
    	while(!queue.isEmpty()) {
    		Vertex ver = queue.poll();
    		// adding the source vertex to the hash map
    		if(ver.i == i1 && ver.j == j1) {
    			dualVertex dVertex1 = new dualVertex(-1,-1,i1,j1,0);
            	if(!this.map.containsKey(0)) {
            		this.map.put(0, dVertex1);
            		dualnode++;
            	}
            	que.add(0);
    		}
    		ArrayList<Edge> arrayList = (ArrayList<Edge>) this.digraph.adj(ver.key);
    		for(Edge edge: arrayList) {
    			Vertex v2 = this.digraph.nodemap(edge.to());
    			queue.add(v2);
    			int newKey = ((ver.i+v2.i)*(2*this.digraph.W()-1)+(ver.j+v2.j));
    			que.add(newKey);
    			dualVertex dVertex2 = new dualVertex(ver.i,ver.j,v2.i,v2.j,newKey);
    			if(!this.map.containsKey(newKey)) {
    				this.map.put(newKey, dVertex2);
    				dualnode++;
    			}
//    			if(notvisitedEdge[que.peek()] || notvisitedEdge[newKey]) {
//    				addEdge(new Edge(que.peek(),newKey,edge.weight()));
//    				notvisitedEdge[que.peek()] = false;
//    				notvisitedEdge[newKey] = false;
//    			}
    			addEdge(new Edge(que.peek(),newKey,edge.weight()));
    		}
    		que.poll();
    	}
	}
    private void validateVertex(int v) {
        if (v < 0 || v >= 4*this.digraph.V())
            throw new IllegalArgumentException("vertex " + v + " is not between 0 and " + (4*this.digraph.V()-1));
    }
	 public void addEdge(Edge e) {
	        int v = e.from();
	        int w = e.to();
	        boolean visitedEdge = false;
	        validateVertex(v);
	        validateVertex(w);
	        for(Edge edge: adj[v]) {
	        	if(edge.to()==w) {
	        		visitedEdge = true;
	        	}
	        }
	        if(!visitedEdge) {
	        	if(v==0) {
		        	double weight = e.weight()+this.costForward;
	    			Edge edge = new Edge(v,w,weight);
	    			adj[v].add(edge);
	    			dualedge++;
		        }
		        else {
		        	// traversing in a row from left to right
		        	if(this.nodemap(v).j2-this.nodemap(v).j1>0) {   
		        		if((this.nodemap(w).j2-this.nodemap(w).j1>0) || (this.nodemap(w).j2-this.nodemap(w).j1<0)) {
		        			double weight = e.weight()+this.costForward;
		        			Edge edge = new Edge(v,w,weight);
		        			adj[v].add(edge);
		        			dualedge++;
		        		}
		        		else if(this.nodemap(w).i2-this.nodemap(w).i1>0) {
		        			double weight = e.weight()+this.costRight;
		        			Edge edge = new Edge(v,w,weight);
		        			adj[v].add(edge);
		        			dualedge++;
		        		}
		        		else if(this.nodemap(w).i2-this.nodemap(w).i1<0) {
		        			double weight = e.weight()+this.costLeft;
		        			Edge edge = new Edge(v,w,weight);
		        			adj[v].add(edge);
		        			dualedge++;
		        		}
		        	}
		        	// traversing in a row from right to left
		        	else if(this.nodemap(v).j2-this.nodemap(v).j1<0) {
		        		if((this.nodemap(w).j2-this.nodemap(w).j1>0) || (this.nodemap(w).j2-this.nodemap(w).j1<0)) {
		        			double weight = e.weight()+this.costForward;
		        			Edge edge = new Edge(v,w,weight);
		        			adj[v].add(edge);
		        			dualedge++;
		        		}
		        		else if(this.nodemap(w).i2-this.nodemap(w).i1>0) {
		        			double weight = e.weight()+this.costLeft;
		        			Edge edge = new Edge(v,w,weight);
		        			adj[v].add(edge);
		        			dualedge++;
		        		}
		        		else if(this.nodemap(w).i2-this.nodemap(w).i1<0) {
		        			double weight = e.weight()+this.costRight;
		        			Edge edge = new Edge(v,w,weight);
		        			adj[v].add(edge);
		        			dualedge++;
		        		}
		        	}
		        	//traversing in a column from up to down
		        	if(this.nodemap(v).i2-this.nodemap(v).i1>0) {   
		        		if((this.nodemap(w).i2-this.nodemap(w).i1>0) || (this.nodemap(w).i2-this.nodemap(w).i1<0)) {
		        			double weight = e.weight()+this.costForward;
		        			Edge edge = new Edge(v,w,weight);
		        			adj[v].add(edge);
		        			dualedge++;
		        		}
		        		else if(this.nodemap(w).j2-this.nodemap(w).j1>0) {
		        			double weight = e.weight()+this.costLeft;
		        			Edge edge = new Edge(v,w,weight);
		        			adj[v].add(edge);
		        			dualedge++;
		        		}
		        		else if(this.nodemap(w).j2-this.nodemap(w).j1<0) {
		        			double weight = e.weight()+this.costRight;
		        			Edge edge = new Edge(v,w,weight);
		        			adj[v].add(edge);
		        			dualedge++;
		        		}
		        	}
		        	// traversing in a column from down to up
		        	if(this.nodemap(v).i2-this.nodemap(v).i1<0) {   
		        		if((this.nodemap(w).i2-this.nodemap(w).i1>0) || (this.nodemap(w).i2-this.nodemap(w).i1<0)) {
		        			double weight = e.weight()+this.costForward;
		        			Edge edge = new Edge(v,w,weight);
		        			adj[v].add(edge);
		        			dualedge++;
		        		}
		        		else if(this.nodemap(w).j2-this.nodemap(w).j1>0) {
		        			double weight = e.weight()+this.costRight;
		        			Edge edge = new Edge(v,w,weight);
		        			adj[v].add(edge);
		        			dualedge++;
		        		}
		        		else if(this.nodemap(w).j2-this.nodemap(w).j1<0) {
		        			double weight = e.weight()+this.costLeft;
		        			Edge edge = new Edge(v,w,weight);
		        			adj[v].add(edge);
		        			dualedge++;
		        		}
		        	}
		        }
	        }
	        
	        
	    }
	 public dualVertex nodemap(int v) {
	        dualVertex ver = this.map.get(v);
	        return ver;
	    }
	 public int dualNodes() {
		 return dualnode;
	 }
	 public int dualEdges() {
		 return dualedge;
	 }
	 public ArrayList<Edge>[] adjacency() {
	        return adj;
	    }
}