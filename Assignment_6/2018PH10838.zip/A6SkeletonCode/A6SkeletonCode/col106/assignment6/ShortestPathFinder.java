package col106.assignment6;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.Queue;

public class ShortestPathFinder implements ShortestPathInterface {
    /**
     * Computes shortest-path from the source vertex s to destination vertex t 
     * in graph G.
     * DO NOT MODIFY THE ARGUMENTS TO THIS CONSTRUCTOR
     *
     * @param  G the graph
     * @param  s the source vertex
     * @param  t the destination vertex 
     * @param left the cost of taking a left turn
     * @param right the cost of taking a right turn
     * @param forward the cost of going forward
     * @throws IllegalArgumentException unless 0 <= s < V
     * @throws IllegalArgumentException unless 0 <= t < V
     * where V is the number of vertices in the graph G.
     */
	private Digraph digraph;
	private int[] source;
	private int[] destination;
	private int costLeft;
	private int costRight;
	private int costForward;
	private dualGraph dualgraph;
	dualVertex[] predecessor;
	ArrayList<dualVertex> shortestpathlist;
	
    public ShortestPathFinder (final Digraph G, final int[] s, final int[] t, 
    final int left, final int right, final int forward) {
        // YOUR CODE GOES HERE
    	this.digraph = G;
    	this.source = s;
    	this.destination = t;
    	this.costLeft = left;
    	this.costRight = right;
    	this.costForward = forward;
    	dualgraph = new dualGraph(G,s,t,left,right,forward);
    	predecessor = new dualVertex[4*this.digraph.V()];
    	shortestpathlist = new ArrayList<dualVertex>();
    }
    // Return number of nodes in dual graph
    public int numDualNodes() {
        // YOUR CODE GOES HERE
    	
        return dualgraph.dualNodes();
    }

    // Return number of edges in dual graph
    public int numDualEdges() {
        // YOUR CODE GOES HERE
        return dualgraph.dualEdges();
    }

    // Return hooks in dual graph
    // A hook (0,0) - (1,0) - (1,2) with weight 8 should be represented as
    // the integer array {0, 0, 1, 0, 1, 2, 8}
    public ArrayList<int[]> dualGraph() {
        // YOUR CODE GOES HERE
    	ArrayList<int[]> hooks = new ArrayList<int[]>();
    	ArrayList<Edge>[] arr = this.dualgraph.adjacency();
    	for(ArrayList<Edge> arraylist: arr) {
    		for(Edge edge: arraylist) {
    			int[] arr1 = new int[7];
    			arr1[0] = this.dualgraph.nodemap(edge.from()).i1;
    			arr1[1] = this.dualgraph.nodemap(edge.from()).j1;
    			arr1[2] = this.dualgraph.nodemap(edge.from()).i2;
    			arr1[3] = this.dualgraph.nodemap(edge.from()).j2;
    			arr1[4] = this.dualgraph.nodemap(edge.to()).i2;
    			arr1[5] = this.dualgraph.nodemap(edge.to()).j2;
    			arr1[6] = (int) edge.weight();
    			hooks.add(arr1);
    		}
    	}
        return hooks;
    }

    // Return true if there is a path from s to t.
    public boolean hasValidPath() {
        // YOUR CODE GOES HERE
    	Queue<Vertex> queue = new ArrayDeque<>();
    	int i = this.source[0];
    	int j = this.source[1];
    	int key = i*this.digraph.W()+j;
    	queue.add(this.digraph.nodemap(key));
    	int i1 = this.destination[0];
		int j1 = this.destination[1];
		int key1 = i1*this.digraph.W()+j1;
    	while(!queue.isEmpty()) {
    		Vertex v = queue.poll();
    		if(v.key == key1) {
    			return true;
    		}
    		ArrayList<Edge> arrayList = (ArrayList<Edge>)this.digraph.adj(v.key);
    		for(Edge edge: arrayList) {
    			queue.add(this.digraph.nodemap(edge.to()));
    		}
    	}
        return false;
    }

    // Return the length of the shortest path from s to t.
    public int ShortestPathValue() {
        // YOUR CODE GOES HERE
    	PriorityQueue<Node> pq = new PriorityQueue<Node>(4*this.digraph.V());
    	double[] distance = new double[4*this.digraph.V()];
    	for(int i=0;i<distance.length;i++) {
    		distance[i] = Integer.MAX_VALUE;
    	}
    	Node src = new Node(this.dualgraph.nodemap(0),0);
    	distance[src.dualvertex.key] = 0;
    	pq.add(src);
    	while(!pq.isEmpty()) {
    		Node node = pq.remove();
    		ArrayList<Edge>[] adj = this.dualgraph.adjacency();
    		for(Edge edge: adj[node.dualvertex.key]) {
    			if(distance[edge.to()]>node.weight+edge.weight()) {
    				distance[edge.to()] = (node.weight+edge.weight());
//    				predecessor[edge.to()] =  this.dualgraph.nodemap(edge.from());
    				pq.add(new Node(this.dualgraph.nodemap(edge.to()),distance[edge.to()]));
    			}
    		}
    	}
    	int desti = destination[0];
    	int destj = destination[1];
    	int distance_value = Integer.MAX_VALUE;
    	int dist_key = 0;
    	int dualkey = 0;
    	ArrayList<Edge>[] adjlist = this.digraph.adjacency();
    	for(ArrayList<Edge> list: adjlist) {
    		for(Edge edge:list) {
    			if(edge.to() == this.digraph.nodemap(desti*this.digraph.W()+destj).key) {
    				dualkey = ((this.digraph.nodemap(edge.from()).i+desti)*(2*this.digraph.W()-1)+(this.digraph.nodemap(edge.from()).j+destj));
    				if(distance_value>distance[dualkey]) {
    					dist_key = dualkey;
    					distance_value = (int) distance[dualkey];
    				}
    			}
    		}
    	}
//    	int dual_key = dualkey;
//    	while(dual_key!=0) {
//			shortestpathlist.add(predecessor[dual_key]);
//			dualVertex vertex1 = predecessor[dual_key];
//			dual_key = vertex1.key;
//
//    	}
//    	shortestpathlist.add(this.dualgraph.nodemap(0));
        return (int) distance[dist_key];
    }

    // Return the shortest path computed from s to t as an ArrayList of nodes, 
    // where each node is represented by its location on the grid.
    public ArrayList<int[]> getShortestPath() {
        // YOUR CODE GOES HERE
    	PriorityQueue<Node> pq = new PriorityQueue<Node>(4*this.digraph.V());
    	double[] distance = new double[4*this.digraph.V()];
    	for(int i=0;i<distance.length;i++) {
    		distance[i] = Integer.MAX_VALUE;
    	}
    	Node src = new Node(this.dualgraph.nodemap(0),0);
    	distance[src.dualvertex.key] = 0;
    	pq.add(src);
    	while(!pq.isEmpty()) {
    		Node node = pq.remove();
    		ArrayList<Edge>[] adj = this.dualgraph.adjacency();
    		for(Edge edge: adj[node.dualvertex.key]) {
    			if(distance[edge.to()]>node.weight+edge.weight()) {
    				distance[edge.to()] = (node.weight+edge.weight());
    				predecessor[edge.to()] =  this.dualgraph.nodemap(edge.from());
    				pq.add(new Node(this.dualgraph.nodemap(edge.to()),distance[edge.to()]));
    			}
    		}
    	}
    	int desti = destination[0];
    	int destj = destination[1];
    	int distance_value = Integer.MAX_VALUE;
    	int dist_key = 0;
    	int dualkey = 0;
    	ArrayList<Edge>[] adjlist = this.digraph.adjacency();
    	for(ArrayList<Edge> list: adjlist) {
    		for(Edge edge:list) {
    			if(edge.to() == this.digraph.nodemap(desti*this.digraph.W()+destj).key) {
    				dualkey = ((this.digraph.nodemap(edge.from()).i+desti)*(2*this.digraph.W()-1)+(this.digraph.nodemap(edge.from()).j+destj));
    				if(distance_value>distance[dualkey]) {
    					dist_key = dualkey;
    					distance_value = (int) distance[dualkey];
    				}
    			}
    		}
    	}
    	int dual_key = dist_key;
    	shortestpathlist.add(this.dualgraph.nodemap(dual_key));
    	while(dual_key!=0) {
			shortestpathlist.add(predecessor[dual_key]);
			dualVertex vertex1 = predecessor[dual_key];
			dual_key = vertex1.key;

    	}

//    	ShortestPathValue();
    	
    	Collections.reverse(shortestpathlist);
    	ArrayList<int[]> arraylist = new ArrayList<int[]>();
    	for(int i=0; i<shortestpathlist.size(); i++) {
    		int[] arr = new int[2];
    		arr[0] = shortestpathlist.get(i).i2;
			arr[1] = shortestpathlist.get(i).j2;
			arraylist.add(arr);
    	}
    	
        return arraylist;
    }
}
